#!/usr/bin/env python3


from brain_games.games.progression import progres


def main():
    progres()


if __name__ == "__main__":
    main()
