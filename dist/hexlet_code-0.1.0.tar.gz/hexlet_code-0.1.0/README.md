### Hexlet tests and linter status:
[![Actions Status](https://github.com/YuriiKostyuk/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/YuriiKostyuk/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/62a9d13c82593706ef11/maintainability)](https://codeclimate.com/github/YuriiKostyuk/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/yLjNzmBs1JnKiZayfmkzxsr6O.svg)](https://asciinema.org/a/yLjNzmBs1JnKiZayfmkzxsr6O)
[![asciicast](https://asciinema.org/a/qdIuTaLnhTAKru8zQfhhpnTL7.svg)](https://asciinema.org/a/qdIuTaLnhTAKru8zQfhhpnTL7)
[![asciicast](https://asciinema.org/a/uQs57HJGwlpkjS8TrXtKCw64u.svg)](https://asciinema.org/a/uQs57HJGwlpkjS8TrXtKCw64u)
[![asciicast](https://asciinema.org/a/WSrYa27dkHGNuLWgaCCPKGLJy.svg)](https://asciinema.org/a/WSrYa27dkHGNuLWgaCCPKGLJy)
[![asciicast](https://asciinema.org/a/hhXS1mfRlTg1ldHIThByWF6hd.svg)](https://asciinema.org/a/hhXS1mfRlTg1ldHIThByWF6hd)